<?php $__env->startSection('content'); ?>





<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Categories</div>

                <div class="card-body">
 


    <table class="table table-striped">
    <thead>
     <tr>
     <th scope="col"> No </th>
  <th scope="col">Edit</th>
<th scope="col">Delete</th>
                                    
</tr>
</thead>
         <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
      <th scope="row"><?php echo e($category->name); ?></th>
             <td> 
<a class="" href="<?php echo e(route('category.edit',['id' =>$category->id ])); ?>">
    <i class="fas fa-edit">Edit</i>
     </a>
    </td>
        <td> 
            
    <a class="" href="<?php echo e(route('category.delete',['id' =>$category->id ])); ?>">
             <i class="far fa-trash-alt">Delete</i>
</a>
  </td> 
    
              
    </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                                  
</tbody>
</table>




                     

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.searchcat', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>