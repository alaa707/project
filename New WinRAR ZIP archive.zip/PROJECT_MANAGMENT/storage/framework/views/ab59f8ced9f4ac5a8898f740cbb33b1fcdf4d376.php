<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>


 


                    <div class="container">
                            <div class="row">
                              <div class="col-sm">
                                    <div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
                                            <div class="card-header">Categories</div>
                                            <div class="card-body">
                                              <h5 class="card-title"><?php echo e($cat_count); ?></h5>
                                             </div>
                                          </div>
                              </div>
                              <div class="col-sm">
                                    <div class="card text-white bg-secondary mb-3" style="max-width: 18rem;">
                                            <div class="card-header">News</div>
                                            <div class="card-body">
                                              <h5 class="card-title"><?php echo e($new_count); ?></h5>
                                             </div>
                                          </div>
                              </div>
                             
                            </div>
                          </div>
                   
                    





                         


                   
                        
                       
                         
                         
                        
                         
                         












                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.searchcat', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>