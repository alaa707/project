<?php $__env->startSection('content'); ?>



<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">News</div>

                <div class="card-body">
 


    <table class="table table-striped">
    <thead>
     <tr>
     <th scope="col"> Subject </th>
 <th scope="col"> Content </th>
 <th scope="col"> Image </th>

  <th scope="col">Edit</th>
<th scope="col">Delete</th>
                                    
</tr>
</thead>
         <tbody>
        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
      <th scope="row"><?php echo e($new->subject); ?></th>
     <th scope="row"><?php echo e($new->content); ?></th>
    <th scope="row"><?php echo e($new->image); ?></th>

<td> 
<a class="" href="<?php echo e(route('new.edit',['id' =>$new->id ])); ?>">
    <i class="fas fa-edit">Edit</i>
     </a>
</td>
<td> 
            
    <a class="" href="<?php echo e(route('new.delete',['id' =>$new->id ])); ?>">
             <i class="far fa-trash-alt">Delete</i>
</a>
</td> 
    
              

              
    </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                                  
</tbody>
</table>




                     

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.searchnews', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>