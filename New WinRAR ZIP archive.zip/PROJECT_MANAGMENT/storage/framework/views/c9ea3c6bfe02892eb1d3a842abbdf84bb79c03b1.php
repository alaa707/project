<?php $__env->startSection('content'); ?>





<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.5.1/min/dropzone.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.5.1/min/dropzone.min.css
">
        </script>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Create New</div>

                <div class="card-body">
                    
                    
                    
                    

                    <?php if(count($errors)>0): ?>
                    <ul class="navbar-nav mr-auto">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item active">
                                     <?php echo e($error); ?>

                                  </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                          </ul>
                          <?php endif; ?>

                    

<form action="<?php echo e(route('new.store')); ?>" method="POST"  >
                        <?php echo e(csrf_field()); ?>

                        
    <div class="form-group">
<label for="exampleFormControlSelect1">Category</label>
     <select class="form-control" name="cat_id" id="cat_id">
         <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <option value="<?php echo e($category->id); ?>" ><?php echo e($category->name); ?></option>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                                     
       </select>
         </div>
                        
                        
                        <div class="form-group">
                          <label for="subject">subject</label>
                          <input type="text" class="form-control" name="subject"  placeholder="Enter subject">
                         </div>
                        
 <br>
 <br>
                        
           <label for="subject">Enter the Content Here</label>
     <br>
<textarea name="content" placeholder="Enter content">
        </textarea>
    <br>
<br>
                        
<!--
     <div class="row" > 
        <div class="col-md-12">  
    <div class="form-group">
    <label for="image">Photo</label>
 <input type="file" class="form-control-file" name="image">
    </div>
         </div>                
                        
    </div> 
-->
    
    <div class="row">
    <div class="col-md-12" >
<lable for="image"  class="dropzone" id="addImage" action="<?php echo e(route('new.store')); ?>">Dropzone
        </lable>
        <input type="hidden" name="image">
        </div>
    
    </div>
    
    
    
    
    
    

    
        <button type="submit" class="btn btn-primary">Save</button>
                      </form> 
                    
                    
<!--                    url('image/do-upload')-->
                    
<!--
                     <form action="<?php echo e(route('new.store')); ?>" class="dropzone" id="addImage">
        
        
        </form>
-->
                    
    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.searchnews', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>