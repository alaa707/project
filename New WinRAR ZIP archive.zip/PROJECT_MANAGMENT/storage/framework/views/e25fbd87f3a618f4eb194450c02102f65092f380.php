

        <form action="/searchnews" method="POST" role="searchnews">
			<?php echo e(csrf_field()); ?>

			<div class="input-group">
				<input type="text" class="form-control" name="q"
					placeholder="Search News"> <span class="input-group-btn">
					<button type="submit" class="btn btn-default">
						<span class="glyphicon glyphicon-search"></span>
					</button>
				</span>
			</div>
		</form>
        <?php if(isset($details)): ?>
        <div class="container">
        <p>the Search results for your Query <b> <?php echo e($query); ?></b> are: </p>

        <h1>News Details:</h1>
            <table>
        <thead>
        <tr>
            <th>subject</th>
             <th>content</th>
         <th>image</th>
  
            
            
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $srchnew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
      <th scope="row"><?php echo e($srchnew->subject); ?></th>
     <th scope="row"><?php echo e($srchnew->content); ?></th>
    <th scope="row"><?php echo e($srchnew->image); ?></th>

<td> 
<a class="" href="<?php echo e(route('new.edit',['id' =>$srchnew->id ])); ?>">
    <i class="fas fa-edit">Edit</i>
     </a>
</td>
<td> 
            
    <a class="" href="<?php echo e(route('new.delete',['id' =>$srchnew->id ])); ?>">
             <i class="far fa-trash-alt">Delete</i>
</a>
</td> 
    
              

              
    </tr>
            
            
            
<!--
            <tr>
            <td><?php echo e($srchnew->subject); ?></td>
            <td><?php echo e($srchnew->content); ?></td>
            <td><?php echo e($srchnew->image); ?></td>
            </tr>
-->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        
        </table>
        </div>
        <?php elseif(isset($message)): ?>

<p><?php echo e($message); ?></p>

        <?php endif; ?>
     