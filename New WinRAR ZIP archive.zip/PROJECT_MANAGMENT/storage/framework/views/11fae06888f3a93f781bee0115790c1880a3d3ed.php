<?php $__env->startSection('content'); ?>






<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Create Category</div>

                <div class="card-body">

                    <?php if(count($errors)>0): ?>
                    <ul class="navbar-nav mr-auto">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item active">
                                     <?php echo e($error); ?>

                                  </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                          </ul>
                          <?php endif; ?>

                    

                    <form action="<?php echo e(route('category.store')); ?>" method="POST"  >
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                          <label for="name">Name</label>
                          <input type="text" class="form-control" name="name"  placeholder="Enter title">
                         </div>
                        
        <label for="description">Enter the Description Here</label>
                                                 <br>

                                                 <br>


                        <textarea name="description">
                        
                        </textarea>
                         <br>
                         <br>
                        <button type="submit" class="btn btn-primary">Save</button>
                      </form>      
                    







                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.searchcat', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>