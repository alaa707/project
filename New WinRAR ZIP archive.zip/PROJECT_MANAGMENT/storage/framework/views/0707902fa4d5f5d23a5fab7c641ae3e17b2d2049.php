<?php $__env->startSection('content'); ?>






<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit news  <?php echo e($news->subject); ?></div>

                <div class="card-body">
 
                  

<form action="<?php echo e(route('new.update' , ['id' => $news->id ])); ?>" method="POST"  >
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                          <label for="subject">New news</label>
                          <input type="text" class="form-control" name="subject"  value="<?php echo e($news->subject); ?>">
                         </div>
              <label for="content">New content </label>  
    
    <textarea name="content" class="form-control" value="<?php echo e($news->content); ?>"></textarea>
                        
                        
                         
                         
                        <button type="submit" class="btn btn-primary">Update</button>
                      </form>      
                    







                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.searchnews', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>