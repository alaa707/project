



<form action="/searchcat" method="POST" role="searchcat">
			<?php echo e(csrf_field()); ?>

			<div class="input-group">
				<input type="text" class="form-control" name="q"
					placeholder="Search Category"> <span class="input-group-btn">
					<button type="submit" class="btn btn-default">
						<span class="glyphicon glyphicon-search"></span>
					</button>
				</span>
			</div>
		</form>
        <?php if(isset($details)): ?>
        <div class="container">
        <p>the Search results for your Query <b> <?php echo e($query); ?></b> are: </p>

        <h1>category Details:</h1>
            <table>
        <thead>
        <tr>
            <th>Name</th>
             <th>description</th>

            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $srhcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($srhcat->name); ?></td>
            <td><?php echo e($srhcat->email); ?></td>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        
        </table>
        </div>
         <?php elseif(isset($message)): ?>

<p><?php echo e($message); ?></p>
        <?php endif; ?>

